function model_train = save_trained_model(name, model_train)
    save(name, 'model_train')
end