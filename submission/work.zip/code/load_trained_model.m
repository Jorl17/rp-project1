function model_train = load_trained_model(name)
    load(name)    
end